
/**
 * Services page
 * - Short list of services (with simple visual cards)
 */
const services = [
  { title: 'Web Development', desc: 'React, Node.js, REST APIs, auth, and deployment.' },
  { title: 'AI & Data', desc: 'Data wrangling, basic ML, and AI integrations into apps.' },
  { title: 'Mobile Prototyping', desc: 'Rapid UI prototypes with React Native / Expo.' }
];

export default function Services(){
  return (
    <div className="container section">
      <h2>Services</h2>
      <div className="grid">
        {services.map((s, i)=> (
          <article className="card" key={i}>
            <h3>{s.title}</h3>
            <p>{s.desc}</p>
          </article>
        ))}
      </div>
    </div>
  );
}
