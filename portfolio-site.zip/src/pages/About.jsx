
/**
 * About page
 * - Includes legal name, image, short bio
 * - Link to downloadable PDF resume
 */
export default function About(){
  return (
    <div className="container section about">
      <img src="/images/mohcine.svg" alt="Mohcine Behate" />
      <div>
        <h2>About Me</h2>
        <p><strong>Name:</strong> Mohcine Behate</p>
        <p>
          I am a Software Engineering Technology student focusing on modern web development
          with React and backend APIs, as well as practical AI integrations.
          I care about clarity, performance, and delivering value to real users.
        </p>
        <p>
          <a href="/resume.pdf" download>Download my Resume (PDF)</a>
        </p>
      </div>
    </div>
  );
}
